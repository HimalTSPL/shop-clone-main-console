export class userInfo {
  userID: number;
  userName: string;
  email: string;
  password: string;
  coPassword: string;
}
