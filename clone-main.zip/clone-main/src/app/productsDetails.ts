export class productsInfo {
  productsID: number;
  productsCategory: string;
  productsName: string;
  productsPrice: string;
  productsQuantity: string;
  productsDescription: string;
}
