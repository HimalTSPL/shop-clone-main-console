import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthoraztionService } from 'src/app/Services/authoraztion.service';
import { userInfo } from 'src/app/updateData';

@Component({
  selector: 'app-view-profile',
  templateUrl: './view-profile.component.html',
  styleUrls: ['./view-profile.component.css'],
})
export class ViewProfileComponent implements OnInit {
  getUserList: any = [];
  userDetails: any = [];
  user_info: userInfo[];
  userName: any = {};
  selectDetails: any

  constructor(private authSrvice: AuthoraztionService, private router: Router) {
    this.user_info = [];
  }

  ngOnInit(): void {
    var va: any = localStorage.getItem('Value');
    this.getUserList = JSON.parse(va);
    console.log('this.getUserList: ', this.getUserList);

    var user: any = localStorage.getItem('token');
    this.userName = user;
  }

  deleteData(index: any) {
    // console.log('index: ', index);

    let userName: any = index.userName;
    let useremail: any;
    let s: any = localStorage.getItem('token');
    if (index.userID >= 0) {
      if (
        userName == s ||
        userName == 'Mr_lakhani' ||
        useremail == 'lakhani@mail.io ̑'
      ) {
        alert('you can not access this data ');
      } else {
        // console.log(index.userID);
        let arr = this.getUserList.filter((a) => a.userID !== index.userID);
        // console.log('arr', arr);
        localStorage.setItem('Value', JSON.stringify(arr));
      }
    }
  }

  details(event) {
    // console.log(event.target.value);
    let select = event.target.value;
    this.selectDetails = "item." + select
    console.log('this.selectDetails: ', this.selectDetails);
  }
}